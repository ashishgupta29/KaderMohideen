﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using RPSApp;
using RPSApp.Enums;
using RPSApp.Interfaces;
using RPSApp.Models;
using System;
using System.IO;

namespace RPSAppTests.Unit
{
    [TestClass, TestCategory("Unit")]
    public class AppTests
    {
        private readonly IGameService _mockGameService
                = Mock.Of<IGameService>(MockBehavior.Strict);

        [TestMethod]
        public void RunTest_ReturnsExpectedResult()
        {
            // Arrange
            var dieValue = DieValue.Rock;
            var output = new StringWriter();
            Console.SetOut(output);

            var input = new StringReader("Somebody");
            Console.SetIn(input);
            var app = GetApp();

            // Act
            app.Run();

            // Assert
            Mock.Get(_mockGameService)
                .Verify(s => s.TryDieValue(It.IsAny<string>(), out dieValue), Times.Exactly(3));
            Mock.Get(_mockGameService)
                .Verify(s => s.Play(It.IsAny<Player>(), It.IsAny<Player>()), Times.Exactly(3));
        }

        private App GetApp()
        {
            var dieValue = DieValue.Rock;
            Mock.Get(_mockGameService)
               .Setup(s => s.TryDieValue(It.IsAny<string>(),out dieValue))
               .Returns(true)
               .Verifiable();
            Mock.Get(_mockGameService)
              .Setup(s => s.Play(It.IsAny<Player>(), It.IsAny<Player>()))
              .Returns("PlayerOne")
              .Verifiable();
            return new App(_mockGameService);
        }
    }

   
}
