﻿using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RPSApp.Enums;
using RPSApp.Models;
using RPSApp.Services;

namespace RPSAppTests.Unit
{
    [TestClass, TestCategory("Unit")]
    public class GameServiceTests
    {
        [TestMethod]
        [DataRow("R", DieValue.Rock, true)]
        [DataRow("P", DieValue.Paper, true)]
        [DataRow("S", DieValue.Scissors, true)]
        [DataRow("Rasdf", DieValue.Rock, false)]
        [DataRow("Paper", DieValue.Rock, false)]
        public void TryDieValueTest_ReturnsExpectedResult(string value, DieValue expectedDieValue, bool expectedResult)
        {
            // Arrange
            DieValue dieValue;
            var gameService = GetGameService();

            // Act
            var result = gameService.TryDieValue(value, out dieValue);

            // Assert
            result.Should().Be(expectedResult);
            dieValue.Should().Be(expectedDieValue);
        }

        [TestMethod]
        [DataRow(DieValue.Rock, DieValue.Paper, "PlayerTwo")]
        [DataRow(DieValue.Paper, DieValue.Scissors, "PlayerTwo")]
        [DataRow(DieValue.Scissors, DieValue.Rock, "PlayerTwo")]
        [DataRow(DieValue.Rock, DieValue.Scissors, "PlayerOne")]
        [DataRow(DieValue.Paper, DieValue.Rock, "PlayerOne")]
        [DataRow(DieValue.Scissors, DieValue.Paper, "PlayerOne")]
        public void PlayTest_ReturnsExpectedResult(DieValue PlayerOneDieValue, DieValue PlayerTwoDieValue, string expectedWinner)
        {
            // Arrange
            var playerOne = GetPlayer("PlayerOne", PlayerOneDieValue);
            var playerTwo = GetPlayer("PlayerTwo", PlayerTwoDieValue);
            var gameService = GetGameService();

            // Act
            var result = gameService.Play(playerOne, playerTwo);

            // Assert
            result.Should().Be(expectedWinner);
        }

        private GameService GetGameService()
        {
            return new GameService();
        }

        private Player GetPlayer(string name, DieValue dieValue)
        {
            return new Player() { Name = name, PlayerValue = dieValue };
        }
    }
}
