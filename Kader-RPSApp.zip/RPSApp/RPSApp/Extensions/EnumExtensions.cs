﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;

namespace RPSApp.Extensions
{
    public static class EnumExtensions
    {
        /// <summary>
        /// Get Enum Display Name.
        /// </summary>
        /// <param name="enumType">Enum.</param>
        /// <returns>Returns the display name of the Enum.</returns>
        public static string ToShortName(this Enum enumType)
        {
            return enumType.GetType().GetMember(enumType.ToString())
                           .First()
                           .GetCustomAttribute<DisplayAttribute>()
                           .Name;
        }
    }
}
