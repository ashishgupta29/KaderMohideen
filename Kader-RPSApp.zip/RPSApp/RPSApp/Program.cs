﻿using Microsoft.Extensions.DependencyInjection;
using RPSApp.Interfaces;
using RPSApp.Services;

namespace RPSApp
{
    class Program
    {
        /// <summary>
        /// main.
        /// </summary>
        /// <param name="args">args.</param>
        public static void Main(string[] args)
        {
            var services = ConfigureServices();

            var serviceProvider = services.BuildServiceProvider();

            serviceProvider.GetService<App>().Run();
        }

        private static IServiceCollection ConfigureServices()
        {
            IServiceCollection services = new ServiceCollection();
            services.AddSingleton<IGameService, GameService>();

            // required to run the application
            services.AddTransient<App>();

            return services;
        }
    }
}
