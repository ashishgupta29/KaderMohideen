﻿using System.ComponentModel.DataAnnotations;

namespace RPSApp.Enums
{
    public enum DieValue
    {
        [Display(Name = "R")]
        Rock,
        [Display(Name = "P")]
        Paper,
        [Display(Name = "S")]
        Scissors,
    }
}
