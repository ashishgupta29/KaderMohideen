﻿using RPSApp.Enums;
using RPSApp.Models;

namespace RPSApp.Interfaces
{
    public interface IGameService
    {
        /// <summary>
        /// Play the game.
        /// </summary>
        /// <param name="playerOne">Player one. </param>
        /// <param name="playerTwo">Player two.</param>
        /// <returns>Returns the winner name as text.</returns>
        string Play(Player playerOne, Player playerTwo);

        /// <summary>
        /// Tey get the die value enum from the string.
        /// </summary>
        /// <param name="value">User entred text.</param>
        /// <param name="dieValue">Out DieValue.</param>
        /// <returns>Returns true if the input string matchs the enum display text.</returns>
        bool TryDieValue(string value, out DieValue dieValue);
    }
}