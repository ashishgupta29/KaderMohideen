﻿using RPSApp.Enums;
using RPSApp.Extensions;
using RPSApp.Interfaces;
using RPSApp.Models;
using System;

namespace RPSApp.Services
{
    public class GameService : IGameService
    {
        /// <inheritdoc/>
        public bool TryDieValue(string value, out DieValue dieValue)
        {
            bool result = true;
            dieValue = DieValue.Rock;

            if (value.ToUpper() == DieValue.Rock.ToShortName())
            {
                dieValue = DieValue.Rock;
            }
            else if (value.ToUpper() == DieValue.Paper.ToShortName())
            {
                dieValue = DieValue.Paper;
            }
            else if (value.ToUpper() == DieValue.Scissors.ToShortName())
            {
                dieValue = DieValue.Scissors;
            }
            else
            {
                result = false;
            }

            return result;
        }

        /// <inheritdoc/>
        public string Play(Player playerOne, Player playerTwo)
        {
            String winner = string.Empty;
            switch (playerOne.PlayerValue)
            {
                case DieValue.Rock:
                    if (playerTwo.PlayerValue == DieValue.Paper)
                    {
                        playerTwo.Points++;
                        winner = playerTwo.Name;
                    }
                    else
                    {
                        playerOne.Points++;
                        winner = playerOne.Name;
                    }
                    break;
                case DieValue.Paper:
                    if (playerTwo.PlayerValue == DieValue.Scissors)
                    {
                        playerTwo.Points++;
                        winner = playerTwo.Name;
                    }
                    else
                    {
                        playerOne.Points++;
                        winner = playerOne.Name;
                    }
                    break;
                case DieValue.Scissors:
                    if (playerTwo.PlayerValue == DieValue.Rock)
                    {
                        playerTwo.Points++;
                        winner = playerTwo.Name;
                    }
                    else
                    {
                        playerOne.Points++;
                        winner = playerOne.Name;
                    }
                    break;
            }
            return winner;
        }


    }
}
