﻿using RPSApp.Enums;
using RPSApp.Interfaces;
using RPSApp.Models;
using System;

namespace RPSApp
{
    public class App
    {
        private readonly IGameService _gameService;
        
        public App(IGameService gameService)
        {
            _gameService = gameService;
        }

        public void Run()
        {
            Console.WriteLine("Welcome to Rock, Paper, Scissors!" + Environment.NewLine);
            Console.WriteLine("Please Enter R to select Rock.");
            Console.WriteLine("Please Enter P to select Paper.");
            Console.WriteLine("Please Enter S to select Scissors.");

            Console.WriteLine("Lets start playing." + Environment.NewLine);

            Player playerOne = new Player() { Name = "Player" };
            Player playerTwo = new Player() { Name = "Computer" };

            int numberOfRounds = 3;
            Random rnd = new Random();

            for (int counter = 1; counter <= numberOfRounds; counter++)
            {
                string key;
                DieValue playerValue;
                do
                {
                    Console.Write("Please Enter for Player Hand: ");
                    key = Console.ReadLine();
                } while (!_gameService.TryDieValue(key, out playerValue));

                playerOne.PlayerValue = playerValue;

                playerTwo.PlayerValue = (DieValue)rnd.Next(0, 3);

                Console.WriteLine($"{playerOne.Name} selected {playerOne.PlayerValue}, {playerTwo.Name} selected {playerTwo.PlayerValue}." + Environment.NewLine);
                if (playerOne.PlayerValue != playerTwo.PlayerValue)
                {
                    var winner = _gameService.Play(playerOne, playerTwo);

                    Console.WriteLine($"{winner} wins a point." + Environment.NewLine);
                }
                else
                {
                    Console.WriteLine($"Tie play. No point for {playerOne.Name} And {playerTwo.Name}." + Environment.NewLine);
                }
            }

            Console.WriteLine("*** Game Results ***");
            Console.WriteLine($"{playerOne.Name} Points : " + playerOne.Points);
            Console.WriteLine($"{playerTwo.Name} Points : " + playerTwo.Points);

            if (playerOne.Points > playerTwo.Points)
            {
                Console.WriteLine($"{playerOne.Name} Wins");
            }
            else if (playerOne.Points < playerTwo.Points)
            {
                Console.WriteLine($"{playerTwo.Name} Wins");
            }
            else
            {
                Console.WriteLine("Tie game.");
            }

            Console.ReadLine();
        }
    }
}
