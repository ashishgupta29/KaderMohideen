﻿using RPSApp.Enums;

namespace RPSApp.Models
{
    public class Player
    {
        public string Name { get; set; }

        public DieValue PlayerValue { get; set; }

        public int Points { get; set; }
    }
}
